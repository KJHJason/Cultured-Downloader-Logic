Object.defineProperty(navigator, "platform", {
    get: function () { return "<OS_NAME>"; },
    set: function (a) {},
});
